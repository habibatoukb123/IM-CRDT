rm -R node1
rm -R node2
rm -R node3
rm -R node4
mkdir node1
mkdir node2
mkdir node3
mkdir node4
mkdir node1/remote
mkdir node2/remote
mkdir node3/remote
mkdir node4/remote
mkdir node1/rootNode
mkdir node2/rootNode
mkdir node3/rootNode
mkdir node4/rootNode